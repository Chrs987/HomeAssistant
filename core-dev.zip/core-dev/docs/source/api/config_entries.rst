.. _config_entries_module:

:mod:`homeassistant.config_entries`
-----------------------------------

.. automodule:: homeassistant.config_entries
    :members:
