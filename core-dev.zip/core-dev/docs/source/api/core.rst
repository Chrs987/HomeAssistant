.. _core_module:

:mod:`homeassistant.core`
-------------------------

.. automodule:: homeassistant.core
    :members: