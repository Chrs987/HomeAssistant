.. _exceptions_module:

:mod:`homeassistant.exceptions`
-------------------------------

.. automodule:: homeassistant.exceptions
    :members:
