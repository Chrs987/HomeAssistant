.. _loader_module:

:mod:`homeassistant.loader`
---------------------------

.. automodule:: homeassistant.loader
    :members:
