================================
Home Assistant API Documentation
================================

Public API documentation for `Home Assistant developers`_.

Contents:

.. toctree::
   :maxdepth: 2
   :glob:

   api/*

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. _Home Assistant developers: https://developers.home-assistant.io/
