"""The aladdin_connect component."""
